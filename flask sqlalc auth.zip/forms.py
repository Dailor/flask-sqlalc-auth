from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField
from wtforms.validators import DataRequired


class RegisterForm(FlaskForm):
    kw_fields = {"class": "form-control"}
    kw_submit = {"class": "btn btn-primary"}

    login = StringField("Login/e-mail", validators=[DataRequired()], render_kw=kw_fields)
    password = PasswordField("Password", validators=[DataRequired()], render_kw=kw_fields)
    password_again = PasswordField("Repeat password", validators=[DataRequired()], render_kw=kw_fields)
    surname = StringField("Surname", validators=[DataRequired()], render_kw=kw_fields)
    name = StringField("Name", validators=[DataRequired()], render_kw=kw_fields)
    age = StringField("Age", validators=[DataRequired()], render_kw=kw_fields)
    position = StringField("Surname", validators=[DataRequired()], render_kw=kw_fields)
    speciality = StringField("Speciality", validators=[DataRequired()], render_kw=kw_fields)
    address = StringField("Address", validators=[DataRequired()], render_kw=kw_fields)
    submit = SubmitField("Submit", render_kw=kw_submit)
