from flask import Flask, render_template, request

from data import db_session

from data.users import User
from data.jobs import Jobs

import datetime

from forms import RegisterForm

app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'


def generate_emain(surname, name, age):
    return f"{surname.lower()}_{name.lower()}_{age}@mars.org"


def add_user(form: RegisterForm):
    user = User()

    user.surname = form.surname.data
    user.name = form.name.data
    user.age = form.age.data

    email = form.login.data
    if "@" not in email:
        user.email = f"{email}@.mars.org"
    else:
        user.email = email

    user.position = form.position.data
    user.speciality = form.speciality.data
    user.address = form.speciality.data
    user.set_password(form.password.data)

    session = db_session.create_session()
    try:
        session.add(user)
        session.commit()
    except:
        return "Такой login/email уже в базе"


@app.route("/register", methods=["GET", "POST"])
def register():
    form = RegisterForm()
    title = "Регистрация"
    msg = {"password_diff": "Пароли не совпадают",
           "password_null": "Поле пароля не может состоять из пробелов",
           "age_num": "В поле с возрастом должно быть число"}
    if request.method == "POST":
        error_msg = ""
        if len(form.password.data.replace(' ', '')) == 0:
            error_msg = msg["password_null"]
        elif form.password.data != form.password_again.data:
            error_msg = msg["password_diff"]
        elif form.age.data.isnumeric() is False:
            error_msg = msg["age_num"]

        if len(error_msg) == 0:
            user_add_result = add_user(form)
            if isinstance(user_add_result, str):
                error_msg = user_add_result

        if len(error_msg) == 0:
            return "<h1>Вы успешно зарегистрированы!</h1>"
        return render_template('registration.html', title=title, form=form, error_msg=error_msg)
    return render_template('registration.html', title=title, form=form)


@app.route('/')
def main_page():
    return render_template('index.html', title='Work', jobs=db_session.create_session().query(Jobs))


def main():
    db_session.global_init("db/blogs.sqlite")
    app.run(debug=True)


if __name__ == '__main__':
    main()
